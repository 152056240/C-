﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Model
{
    class CreateNote
    {
        private String notename;

        public String Notename
        {
            get { return notename; }
            set { notename = value; }
        }

        private String noteclass;

        public String Noteclass
        {
            get { return noteclass; }
            set { noteclass = value; }
        }

        private String path;

        public String Path
        {
            get { return path; }
            set { path = value; }
        }
    }
}
