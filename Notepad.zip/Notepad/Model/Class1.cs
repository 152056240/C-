﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Model
{
   public class Class1
    {
      
            public static string aa;

            public static string getA
            {
                get { return aa; }
            }

            public static string setA
            {
                set { aa = value; }
            }
        
    }
}
