﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using Model;

namespace Notepad
{
    public partial class FormClass : Form
    {
        public FormClass()
        {
            InitializeComponent();
        }
        public void bind()
        {
            DataTable dt = new DataTable();
            SqlConnection sqlcon = new SqlConnection(@"Data Source=LENOVO-PC\SQLSERVER;Initial Catalog=Notepad;Integrated Security=True");
            sqlcon.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from CreateNote", sqlcon);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            sqlcon.Close();
        }

        private void FormClass_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=LENOVO-PC\SQLSERVER;Initial Catalog=Notepad;Integrated Security=True");
            SqlCommand cmd = conn.CreateCommand();
            conn.Open();//连接数据
            SqlDataAdapter da = new SqlDataAdapter("select notename 笔记名称, noteclass 笔记分类,path 笔记内容 from CreateNote", conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            conn.Close();

            //定义窗体form传值
            textBox1.Text = "";
            textBox2.Text = "";
            richTextBox1.Text = "";
            bind();
            //定义窗体传值为只读
            textBox1.ReadOnly = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FormMain main = new FormMain();
            this.Hide();
            main.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormMain main = new FormMain();
            this.Hide();
            main.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string select = "delete from CreateNote where notename='" + textBox1.Text + "'";
            string str = @"Data Source=LENOVO-PC\SQLSERVER;Initial Catalog=Notepad;Integrated Security=True";
            SqlConnection conn = new SqlConnection(str);
            conn.Open();
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand(select, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Close();
            SqlDataAdapter da = new SqlDataAdapter("select notename 笔记名称,noteclass 笔记分类,path 笔记内容 from CreateNote", conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            conn.Close();
            MessageBox.Show("删除笔记成功!");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = "";
            try
            {
                if (e.RowIndex < dataGridView1.RowCount - 1)
                    textBox1.Text = "" + dataGridView1.Rows[e.RowIndex].Cells[0].Value;
            }
            catch (Exception ex)
            {
                MessageBox.Show("需要选择一个记录", "信息提示");
            }


            textBox2.Text = "";
            try
            {
                if (e.RowIndex < dataGridView1.RowCount - 1)
                    textBox2.Text = "" + dataGridView1.Rows[e.RowIndex].Cells[1].Value;
            }
            catch (Exception ex)
            {
                MessageBox.Show("需要选择一个记录", "信息提示");
            }
            richTextBox1.Text = "";
            try
            {
                if (e.RowIndex < dataGridView1.RowCount - 1)
                    richTextBox1.Text = "" + dataGridView1.Rows[e.RowIndex].Cells[2].Value;
            }
            catch (Exception ex)
            {
                MessageBox.Show("需要选择一个记录", "信息提示");
            }
            Class2.aa = textBox1.Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string select = "update CreateNote set notename='" + textBox1.Text.ToString() + "',noteclass='" + textBox2.Text.ToString() + "',path='" + richTextBox1.Text.ToString() + "'where notename='" + textBox1.Text.ToString() + "'";
            string str = @"Data Source=LENOVO-PC\SQLSERVER;Initial Catalog=Notepad;Integrated Security=True";
            SqlConnection conn = new SqlConnection(str);
            conn.Open();
            SqlCommand cmd = new SqlCommand(select, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            bind();
            MessageBox.Show("修改笔记成功！");

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        
    }
}