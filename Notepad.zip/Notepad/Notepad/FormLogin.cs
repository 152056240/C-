﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data;
using System.Data.SqlClient;
using Model;


namespace Notepad
{
    public partial class FormLogin : Form
    {
       
        public FormLogin()
        {
            InitializeComponent();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=LENOVO-PC\SQLSERVER;Initial Catalog=Notepad;Integrated Security=True");
            conn.Open();//连接数据库
            String username = loginname.Text;
            String password = loginpass.Text;
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "select * from Users where username='" + username + "'";
            //查找数据库里是否有该用户名                
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {

                //用户名存在
                Class1.setA = loginname.Text;
                string dbpassword = reader.GetString(reader.GetOrdinal("password"));
                //textBox1.Text = dbpassword;
                if (password == dbpassword)
                {
                    string name = reader.GetString(reader.GetOrdinal("username"));
                    MessageBox.Show("您好，" + name + "。欢迎您！");
                    this.DialogResult = DialogResult.OK;
                    FormMain frmmain = new FormMain();
                    frmmain.ShowDialog();
                }
                else
                {
                    MessageBox.Show("用户名或密码错误！");
                }
            }
            else
            {
                MessageBox.Show("用户名或密码错误！");
            }


            conn.Close();      
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormAdd_user f = new FormAdd_user();
            f.ShowDialog();
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {

        } 
    }
    
}
