﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Notepad
{
    public partial class FormAdd_user : Form
    {
        public void bind()
        {
            DataTable dt = new DataTable();
            SqlConnection sqlcon = new SqlConnection(@"Data Source=LENOVO-PC\SQLSERVER;Initial Catalog=Notepad;Integrated Security=True");
            sqlcon.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from Users", sqlcon);
            da.Fill(dt);
            sqlcon.Close();
        }
        public FormAdd_user()
        {
            InitializeComponent();
        }

        private void FormAdd_user_Load(object sender, EventArgs e)
        {
            bind();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBoxUserPwd.Text == textBoxUserPwd1.Text)
            {
                try
                {
                    string select = "insert into users values('" + textBoxUserName.Text + "','" + textBoxUserPwd1.Text + "')";
                    string str = @"Data Source=LENOVO-PC\SQLSERVER;Initial Catalog=Notepad;Integrated Security=True";
                    SqlConnection conn = new SqlConnection(str);
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(select, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    bind();

                    MessageBox.Show("添加新用户成功！");
                }
                catch (Exception err)
                {
                    MessageBox.Show("添加新用户失败！" + err.ToString(), "错误！");
                }
            }
            else
            {
                MessageBox.Show("确认密码错误！请重新输入");
                textBoxUserPwd1.Text = "";
                textBoxUserPwd1.Focus();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
