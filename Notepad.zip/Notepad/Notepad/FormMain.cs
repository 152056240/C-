﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Printing;
using System.Data.SqlClient;
using Model;

namespace Notepad
{
    public partial class FormMain : Form
    {
        //public string username;
        //public string LoginTime;
        //public string classname;
        //public string notename;
        public string path;
        //public int a = 0;
        //public int i = -1;
        //public int k = 0;
        //public int j = 0;
        //public int b = 0;
        //public int c = 0;
        //public int d = 0;
        //public int f = 0;
        public string rtb = "";
        //public int g = 0;
        //public string content;
        //String s_FileName = "";
        //bool bSave = false;
        //int FindPostion = 0;
        //public bool IfSaveOldFile();
        public void bind()
        {
            DataTable dt = new DataTable();
            SqlConnection sqlcon = new SqlConnection(@"Data Source=LENOVO-PC\SQLSERVER;Initial Catalog=Notepad;Integrated Security=True");
            sqlcon.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from CreateNote", sqlcon);
            sqlcon.Close();
        }
        public FormMain()
        {
            InitializeComponent();
        }
        
        private void 新建ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            richTextBox1.Clear();
            //FormAddnote addnote = new FormAddnote();
            //addnote.ShowDialog();

            //if (!IfSaveOldFile())
            //    return;
            //richTextBox1.Text = "";
            //s_FileName = "";
        }

        private void 打开ToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
        }

        private void 保存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            

        }

        //private void 另存为ToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        ////    try
        ////    {
        ////        if (d == 1)
        ////        {
        ////            saveFileDialog1.Filter = @"文本文档(*.txt)|*.txt|所有格式|*.txt;*.doc;*.cs;*.rtf;*.sln";
        ////            saveFileDialog1.ShowDialog();
        ////            richTextBox1.SaveFile(saveFileDialog1.FileName, RichTextBoxStreamType.PlainText);
        ////            this.Text = Path.GetFileName(saveFileDialog1.FileName) + "- 记事本";
        ////            path = saveFileDialog1.FileName;
        ////            rtb = richTextBox1.Text;
        ////        }
        ////    }
        ////    catch { }
        ////    //StreamWriter myStream;
        ////    //saveFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
        ////    //saveFileDialog1.FilterIndex = 2;
        ////    //saveFileDialog1.RestoreDirectory = true;
        ////    //if (saveFileDialog1.ShowDialog() == DialogResult.OK)
        ////    //{
        ////    //    myStream = new StreamWriter(saveFileDialog1.FileName);
        ////    //    myStream.Write(richTextBox1.Text); //写入
        ////    //    myStream.Close();//关闭流
        ////    //}
        //}

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void 剪切ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Cut();
        }

        private void 复制ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();
        }

        private void 粘贴ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Paste();
        }

        private void 全选ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectAll();
        }


        private void 颜色ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            if (richTextBox1.SelectionLength > 0)
                if (colorDialog1.ShowDialog() == DialogResult.OK)
                {
                    richTextBox1.SelectionColor = colorDialog1.Color;
                }
        }
       
        private void 字体ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (richTextBox1.SelectionLength > 0)
                if (fontDialog1.ShowDialog() == DialogResult.OK)
                {
                    richTextBox1.SelectionFont = fontDialog1.Font;
                }
        }

        private void 关于记事本ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAbout about = new FormAbout();
            about.ShowDialog();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
           
            toolStripStatusLabel2.Text = Class1.aa;
            //d = 1;
            //saveFileDialog1.FileName = "*.txt";
            //openFileDialog1.FileName = "*.txt";
            //richTextBox1.Text = content;
            bind();
        }

        private void 页面设置ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                pageSetupDialog1.Document = printDocument1;
                pageSetupDialog1.Document.DefaultPageSettings.Color = false;
                this.pageSetupDialog1.ShowDialog();
            }
            catch { }
        }

        private void 打印ToolStripMenuItem_Click(object sender, EventArgs e)

        {
             MessageBox.Show("未安装打印机！");
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void 退出程序ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void 分类管理ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FormClass cl = new FormClass();
            this.Hide();
            cl.ShowDialog();
        }

        private void 保存在本地ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    if (d == 1)
            //    {
                    saveFileDialog1.Filter = @"文本文档(*.txt)|*.txt|所有格式|*.txt;*.doc;*.cs;*.rtf;*.sln";
                    saveFileDialog1.ShowDialog();
                    richTextBox1.SaveFile(saveFileDialog1.FileName, RichTextBoxStreamType.PlainText);
                    this.Text = Path.GetFileName(saveFileDialog1.FileName) + "- 记事本";
                    path = saveFileDialog1.FileName;
                    rtb = richTextBox1.Text;
            //    }
            //}
            //catch { }

            //try
            //{
            //    if (this.Text == "无标题－记事本")
            //    {
            //        if (d == 1)
            //        {
            //            saveFileDialog1.Filter = @"文本文档(*.txt)|*.txt|所有格式|*.txt;*.doc;*.cs;*.rtf;*.sln";
            //            saveFileDialog1.ShowDialog();
            //            richTextBox1.SaveFile(saveFileDialog1.FileName, RichTextBoxStreamType.PlainText);
            //            this.Text = Path.GetFileName(saveFileDialog1.FileName) + "- 记事本";
            //            path = saveFileDialog1.FileName;
            //            MessageBox.Show(path);
            //        }

            //    }
            //    else
            //    {
            //        saveFileDialog1.Filter = @"|*.txt;*.cs";
            //        if (this.Text == Path.GetFileName(openFileDialog1.FileName) + "- 记事本")
            //            richTextBox1.SaveFile(openFileDialog1.FileName, RichTextBoxStreamType.PlainText);

            //    }
            //    rtb = richTextBox1.Text;
            //}
            //catch { }

            
            //StreamWriter myStream;
            //saveFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            //saveFileDialog1.FilterIndex = 2;
            //saveFileDialog1.RestoreDirectory = true;
            //if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            //{
            //    myStream = new StreamWriter(saveFileDialog1.FileName);
            //    myStream.Write(richTextBox1.Text); //写入
            //    myStream.Close();//关闭流
            //}
        }

        private void 保存到数据库ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=LENOVO-PC\SQLSERVER;Initial Catalog=Notepad;Integrated Security=True");
            conn.Open();//连接数据库
            SqlCommand cmd = conn.CreateCommand();
            cmd.Connection = conn;
            string select = "insert into CreateNote(notename,noteclass,path) values('" + textBox1.Text + "','" + textBox2.Text + "','" + richTextBox1.Text + "')";
            cmd.CommandText = select;
            try
            {
                if (textBox1.Text != "" && textBox2.Text != "" && richTextBox1.Text != "")
                {
                    int n = cmd.ExecuteNonQuery();
                    MessageBox.Show("添加笔记成功！");
                    
                }
                else
                {
                    MessageBox.Show("每一项都需要填写哦！");
                }
            }
            catch (Exception err)
            {
                MessageBox.Show("添加笔记失败！" + err.ToString(), "错误！");
            }
            //{
            //    if (s_FileName.Length != 0)//文件已经保存过
            //    {
            //        bSave = false;
            //        richTextBox1.SaveFile(s_FileName, RichTextBoxStreamType.PlainText);
            //    }
            //    else
            //        另存为ToolStripMenuItem_Click(sender, e);//文件另存
            //}

        }

        private void 打开本地ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result;
            try
            {
                if (rtb != richTextBox1.Text)
                {
                    result = MessageBox.Show("文件 " + this.Text + " 的文字已经改变。\r\n\r\n想保存文件吗？", "记事本", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Exclamation);
                    if (result == DialogResult.Yes)
                    {
                        saveFileDialog1.Filter = @"文本文档(*.txt)|*.txt|所有格式|*.txt;*.doc;*.cs;*.rtf;*.sln";
                        saveFileDialog1.ShowDialog();
                        richTextBox1.SaveFile(saveFileDialog1.FileName, RichTextBoxStreamType.PlainText);
                        openFileDialog1.Filter = @"文本文档(*.txt)|*.txt|所有格式|*.txt;*.doc;*.cs;*.rtf;*.sln";
                        openFileDialog1.ShowDialog();
                        richTextBox1.LoadFile(openFileDialog1.FileName, RichTextBoxStreamType.PlainText);
                        rtb = richTextBox1.Text;
                        path = openFileDialog1.FileName;
                    }
                    else if (result == DialogResult.No)
                    {
                        openFileDialog1.Filter = @"文本文档(*.txt)|*.txt|所有格式|*.txt;*.doc;*.cs;*.rtf;*.sln";
                        openFileDialog1.ShowDialog();
                        richTextBox1.LoadFile(openFileDialog1.FileName, RichTextBoxStreamType.PlainText);
                        rtb = richTextBox1.Text;
                    }

                }
                else
                {
                    openFileDialog1.Filter = @"文本文档(*.txt)|*.txt|所有格式|*.txt;*.doc;*.cs;*.rtf;*.sln";
                    openFileDialog1.ShowDialog();
                    richTextBox1.LoadFile(openFileDialog1.FileName, RichTextBoxStreamType.PlainText);
                    rtb = richTextBox1.Text;
                }
                this.Text = Path.GetFileName(openFileDialog1.FileName) + "- 记事本";
                saveFileDialog1.FileName = openFileDialog1.FileName;

            }
            catch { }
            


            //if (!IfSaveOldFile())
            //    return;
            //OpenFileDialog saveFileDialog1 = new OpenFileDialog();
            //openFileDialog1.Filter = "文本文档(*txt)|*txt|所有文件(*.*)|*.* ";
            //openFileDialog1.FilterIndex = 1;
            //if (openFileDialog1.ShowDialog() == DialogResult.OK)
            //{
            //    s_FileName = openFileDialog1.FileName;
            //    richTextBox1.LoadFile(openFileDialog1.FileName, RichTextBoxStreamType.PlainText);
            //}
        }

        private void 打开数据库ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormClass cl = new FormClass();
            this.Hide();
            cl.ShowDialog();
        }

       
      }
    }

   